// Tab Keeper - Content Script
// Detects if user is logged out and requests auto-login
// Checks multiple times to handle slow-loading pages
// ONLY triggers auto-login on the configured target site

let loginCheckTimeout = null;
let loginAttempted = false;
let checkAttempts = 0;
const MAX_CHECK_ATTEMPTS = 5; // Check up to 5 times over 7 seconds
let targetUrl = null; // Store target URL to verify we're on the right site

// Extract base URL (domain + first path segment) for matching
function getBaseUrl(url) {
  try {
    const urlObj = new URL(url);
    const firstPath = urlObj.pathname.split('/')[1] || '';
    return urlObj.origin + (firstPath ? '/' + firstPath : '');
  } catch (e) {
    return url;
  }
}

// Check if a URL matches the target
function isTargetUrl(currentUrl, targetUrl) {
  if (!currentUrl || !targetUrl) return false;
  
  if (currentUrl === targetUrl) return true;
  if (currentUrl.startsWith(targetUrl)) return true;
  
  const currentBase = getBaseUrl(currentUrl);
  const targetBase = getBaseUrl(targetUrl);
  
  if (currentBase === targetBase) return true;
  
  try {
    const currentDomain = new URL(currentUrl).hostname;
    const targetDomain = new URL(targetUrl).hostname;
    if (currentDomain === targetDomain) return true;
  } catch (e) {}
  
  return false;
}

// Check for login status
function startLoginMonitoring() {  
  chrome.runtime.sendMessage({ action: 'getTargetUrl' }, (response) => {
    if (response && response.targetUrl) {
      targetUrl = response.targetUrl;      checkLoginStatusDelayed();
    } else {    }
  });
}

function checkLoginStatusDelayed() {
  if (loginCheckTimeout) {
    clearTimeout(loginCheckTimeout);
  }
  
  const delay = checkAttempts === 0 ? 1000 : (checkAttempts < 2 ? 1500 : 2000);
  
  loginCheckTimeout = setTimeout(() => {
    checkLoginStatus();
  }, delay);
}

function checkLoginStatus() {
  checkAttempts++;  
  // Verify we're on the target site before checking for login page
  if (targetUrl) {
    const currentUrl = window.location.href;
    const isTargetSite = isTargetUrl(currentUrl, targetUrl);
    
    if (!isTargetSite) {      return;
    }
  }
  
  const hasPasswordField = document.querySelector('input[type="password"]') !== null;
  const hasLoginForm = document.querySelector('form[action*="login"], form[action*="signin"], .login-form, #login-form') !== null;
  const hasUsernameField = document.querySelector('input[name*="user"], input[name*="email"], #username, #email, [name="username"]') !== null;
  
  const bodyText = document.body.innerText.toLowerCase();
  const titleText = document.title.toLowerCase();
  const loginKeywords = ['sign in', 'log in', 'username', 'password', 'email address'];
  const hasKeywords = loginKeywords.some(word => bodyText.includes(word) || titleText.includes(word));

  const isLoginPage = hasPasswordField || hasLoginForm || (hasUsernameField && hasKeywords);

  if (isLoginPage && !loginAttempted) {    loginAttempted = true;
    
    chrome.runtime.sendMessage({ action: 'loginRequired' }, (response) => {
      if (response) {      } else {        loginAttempted = false;
      }
    });
  } else if (!isLoginPage) {    return;
  } else if (loginAttempted) {    return;
  } else {    if (checkAttempts < MAX_CHECK_ATTEMPTS) {
      checkLoginStatusDelayed();
    }
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'checkLogin') {
    checkLoginStatus();
    sendResponse({ status: 'checked' });
  }
  
  if (request.action === 'resetLoginAttempt') {
    loginAttempted = false;    sendResponse({ status: 'reset' });
  }
  
  return true;
});

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', startLoginMonitoring);
} else {
  startLoginMonitoring();
}

window.addEventListener('beforeunload', () => {
  if (loginCheckTimeout) {
    clearTimeout(loginCheckTimeout);
  }
});
