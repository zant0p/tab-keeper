// Tab Keeper - Content Script
// Detects if user is logged out and requests auto-login
// Checks multiple times to handle slow-loading pages
// Also handles dismissing Chrome's "Change your password" popup

let loginCheckTimeout = null;
let loginAttempted = false;
let checkAttempts = 0;
const MAX_CHECK_ATTEMPTS = 5; // Check up to 5 times over 7 seconds
let passwordPopupDismissed = false;

// Check for login status
function startLoginMonitoring() {
  console.log('Tab Keeper Content: Starting login monitoring');
  checkLoginStatusDelayed();
}

function checkLoginStatusDelayed() {
  // Clear any existing timeout
  if (loginCheckTimeout) {
    clearTimeout(loginCheckTimeout);
  }
  
  // Delay increases with each attempt: 1s, 1.5s, 2s, 2s, 2s
  const delay = checkAttempts === 0 ? 1000 : (checkAttempts < 2 ? 1500 : 2000);
  
  loginCheckTimeout = setTimeout(() => {
    checkLoginStatus();
  }, delay);
}

function checkLoginStatus() {
  checkAttempts++;
  console.log(`Tab Keeper Content: Login check attempt ${checkAttempts}/${MAX_CHECK_ATTEMPTS}`);
  
  // Look for password field (strongest indicator)
  const hasPasswordField = document.querySelector('input[type="password"]') !== null;
  
  // Look for login form
  const hasLoginForm = document.querySelector('form[action*="login"], form[action*="signin"], .login-form, #login-form') !== null;
  
  // Look for common login input names/ids
  const hasUsernameField = document.querySelector('input[name*="user"], input[name*="email"], #username, #email, [name="username"]') !== null;
  
  // Check page text for login keywords
  const bodyText = document.body.innerText.toLowerCase();
  const titleText = document.title.toLowerCase();
  
  const loginKeywords = ['sign in', 'log in', 'username', 'password', 'email address'];
  const hasKeywords = loginKeywords.some(word => bodyText.includes(word) || titleText.includes(word));

  const isLoginPage = hasPasswordField || hasLoginForm || (hasUsernameField && hasKeywords);

  if (isLoginPage && !loginAttempted) {
    console.log('Tab Keeper Content: Login page detected, requesting auto-login');
    loginAttempted = true;
    
    chrome.runtime.sendMessage({ action: 'loginRequired' }, (response) => {
      if (response) {
        console.log('Tab Keeper Content: Auto-login initiated');
      } else {
        console.log('Tab Keeper Content: No response from background, will retry');
        loginAttempted = false; // Allow retry
      }
    });
  } else if (!isLoginPage) {
    console.log('Tab Keeper Content: Not a login page');
    // Not a login page, no need to keep checking
    return;
  } else if (loginAttempted) {
    console.log('Tab Keeper Content: Already attempted login');
    return;
  } else {
    console.log('Tab Keeper Content: Login fields not found yet, will check again');
    // Keep trying if we haven't hit max attempts
    if (checkAttempts < MAX_CHECK_ATTEMPTS) {
      checkLoginStatusDelayed();
    }
  }
}

// Dismiss Chrome's "Change your password" popup
function dismissPasswordPopup() {
  console.log('Tab Keeper Content: Attempting to dismiss password change popup');
  
  // Strategy 1: Common selectors for Chrome's password change popup
  const popupSelectors = [
    '#change-password-prompt',
    '[data-action="close"]',
    '.password-change-dialog',
    'button[aria-label*="close" i]',
    'button[aria-label*="dismiss" i]',
    '.mdc-dialog__actions button:last-child', // "Not now" or close button
    'google-chrome-change-password',
    '[role="dialog"] button:last-child',
    // Chrome-specific selectors
    'cr-dialog',
    'ui-manager',
    '[class*="password-bubble"]',
    '[class*="save-password"]',
    '[class*="chrome-password"]'
  ];
  
  for (const selector of popupSelectors) {
    const closeButton = document.querySelector(selector);
    if (closeButton) {
      console.log('Tab Keeper Content: Found password popup close button:', selector);
      closeButton.click();
      passwordPopupDismissed = true;
      return true;
    }
  }
  
  // Strategy 2: Try to find any dialog with password-related text
  const dialogs = document.querySelectorAll('[role="dialog"], .mdc-dialog, dialog, cr-dialog');
  for (const dialog of dialogs) {
    const dialogText = dialog.innerText.toLowerCase();
    if (dialogText.includes('password') && (dialogText.includes('change') || dialogText.includes('save') || dialogText.includes('update'))) {
      console.log('Tab Keeper Content: Found password dialog by text content');
      // Try to click the last button (usually "Not now", "Cancel", or close)
      const buttons = dialog.querySelectorAll('button, [role="button"], input[type="button"]');
      if (buttons.length > 0) {
        // Look for "Not now", "Cancel", or close button first
        let targetButton = null;
        for (const btn of buttons) {
          const btnText = btn.innerText.toLowerCase();
          if (btnText.includes('not now') || btnText.includes('cancel') || btnText.includes('close') || btnText.includes('dismiss')) {
            targetButton = btn;
            break;
          }
        }
        // If no specific button found, use the last one
        if (!targetButton) {
          targetButton = buttons[buttons.length - 1];
        }
        console.log('Tab Keeper Content: Clicking button:', targetButton.innerText || targetButton.textContent);
        targetButton.click();
        passwordPopupDismissed = true;
        return true;
      }
    }
  }
  
  // Strategy 3: Look for overlay/backdrop clicks (some popups close when clicking outside)
  const overlays = document.querySelectorAll('.mdc-dialog__scrim, .dialog-backdrop, [class*="backdrop"], [class*="overlay"]');
  if (overlays.length > 0) {
    console.log('Tab Keeper Content: Found overlay, attempting backdrop click');
    overlays[0].click();
    passwordPopupDismissed = true;
    return true;
  }
  
  // Strategy 4: Send Escape key (works for some native dialogs)
  console.log('Tab Keeper Content: Sending Escape key to dismiss popup');
  document.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  
  console.log('Tab Keeper Content: No password popup found to dismiss');
  return false;
}

// Listen for messages from background
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'checkLogin') {
    checkLoginStatus();
    sendResponse({ status: 'checked' });
  }
  
  if (request.action === 'resetLoginAttempt') {
    loginAttempted = false;
    console.log('Tab Keeper Content: Login attempt reset');
    sendResponse({ status: 'reset' });
  }
  
  if (request.action === 'dismissPasswordPopup') {
    const dismissed = dismissPasswordPopup();
    sendResponse({ status: dismissed ? 'dismissed' : 'not_found' });
  }
  
  if (request.action === 'forceDismissPasswordPopup') {
    // Aggressive mode - try multiple times with delays
    console.log('Tab Keeper Content: Force dismiss requested');
    let attempts = 0;
    const maxAttempts = 3;
    
    function tryDismiss() {
      attempts++;
      const result = dismissPasswordPopup();
      if (!result && attempts < maxAttempts) {
        setTimeout(tryDismiss, 300); // Try again in 300ms
      } else {
        sendResponse({ status: result ? 'dismissed' : 'failed', attempts: attempts });
      }
    }
    
    tryDismiss();
    return true; // Keep channel open for async response
  }
  
  return true; // Keep channel open
});

// Start when page is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', startLoginMonitoring);
} else {
  startLoginMonitoring();
}

// Cleanup
window.addEventListener('beforeunload', () => {
  if (loginCheckTimeout) {
    clearTimeout(loginCheckTimeout);
  }
});
