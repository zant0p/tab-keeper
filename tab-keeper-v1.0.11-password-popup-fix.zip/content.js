// Tab Keeper - Content Script
// Detects if user is logged out and requests auto-login
// Checks multiple times to handle slow-loading pages
// Also handles dismissing Chrome's "Change your password" popup

let loginCheckTimeout = null;
let loginAttempted = false;
let checkAttempts = 0;
const MAX_CHECK_ATTEMPTS = 5; // Check up to 5 times over 7 seconds
let passwordPopupDismissed = false;

// Check for login status
function startLoginMonitoring() {
  console.log('Tab Keeper Content: Starting login monitoring');
  checkLoginStatusDelayed();
}

function checkLoginStatusDelayed() {
  // Clear any existing timeout
  if (loginCheckTimeout) {
    clearTimeout(loginCheckTimeout);
  }
  
  // Delay increases with each attempt: 1s, 1.5s, 2s, 2s, 2s
  const delay = checkAttempts === 0 ? 1000 : (checkAttempts < 2 ? 1500 : 2000);
  
  loginCheckTimeout = setTimeout(() => {
    checkLoginStatus();
  }, delay);
}

function checkLoginStatus() {
  checkAttempts++;
  console.log(`Tab Keeper Content: Login check attempt ${checkAttempts}/${MAX_CHECK_ATTEMPTS}`);
  
  // Look for password field (strongest indicator)
  const hasPasswordField = document.querySelector('input[type="password"]') !== null;
  
  // Look for login form
  const hasLoginForm = document.querySelector('form[action*="login"], form[action*="signin"], .login-form, #login-form') !== null;
  
  // Look for common login input names/ids
  const hasUsernameField = document.querySelector('input[name*="user"], input[name*="email"], #username, #email, [name="username"]') !== null;
  
  // Check page text for login keywords
  const bodyText = document.body.innerText.toLowerCase();
  const titleText = document.title.toLowerCase();
  
  const loginKeywords = ['sign in', 'log in', 'username', 'password', 'email address'];
  const hasKeywords = loginKeywords.some(word => bodyText.includes(word) || titleText.includes(word));

  const isLoginPage = hasPasswordField || hasLoginForm || (hasUsernameField && hasKeywords);

  if (isLoginPage && !loginAttempted) {
    console.log('Tab Keeper Content: Login page detected, requesting auto-login');
    loginAttempted = true;
    
    chrome.runtime.sendMessage({ action: 'loginRequired' }, (response) => {
      if (response) {
        console.log('Tab Keeper Content: Auto-login initiated');
      } else {
        console.log('Tab Keeper Content: No response from background, will retry');
        loginAttempted = false; // Allow retry
      }
    });
  } else if (!isLoginPage) {
    console.log('Tab Keeper Content: Not a login page');
    // Not a login page, no need to keep checking
    return;
  } else if (loginAttempted) {
    console.log('Tab Keeper Content: Already attempted login');
    return;
  } else {
    console.log('Tab Keeper Content: Login fields not found yet, will check again');
    // Keep trying if we haven't hit max attempts
    if (checkAttempts < MAX_CHECK_ATTEMPTS) {
      checkLoginStatusDelayed();
    }
  }
}

// Dismiss Chrome's "Change your password" popup
function dismissPasswordPopup() {
  console.log('Tab Keeper Content: Attempting to dismiss password change popup');
  
  // Common selectors for Chrome's password change popup
  const popupSelectors = [
    '#change-password-prompt',
    '[data-action="close"]',
    '.password-change-dialog',
    'button[aria-label*="close" i]',
    'button[aria-label*="dismiss" i]',
    '.mdc-dialog__actions button:last-child', // "Not now" or close button
    'google-chrome-change-password',
    '[role="dialog"] button:last-child'
  ];
  
  for (const selector of popupSelectors) {
    const closeButton = document.querySelector(selector);
    if (closeButton) {
      console.log('Tab Keeper Content: Found password popup close button:', selector);
      closeButton.click();
      passwordPopupDismissed = true;
      return true;
    }
  }
  
  // Try to find any dialog with password-related text
  const dialogs = document.querySelectorAll('[role="dialog"], .mdc-dialog, dialog');
  for (const dialog of dialogs) {
    const dialogText = dialog.innerText.toLowerCase();
    if (dialogText.includes('password') && dialogText.includes('change')) {
      console.log('Tab Keeper Content: Found password dialog by text content');
      // Try to click the last button (usually "Not now" or close)
      const buttons = dialog.querySelectorAll('button');
      if (buttons.length > 0) {
        buttons[buttons.length - 1].click();
        passwordPopupDismissed = true;
        return true;
      }
    }
  }
  
  console.log('Tab Keeper Content: No password popup found to dismiss');
  return false;
}

// Listen for messages from background
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'checkLogin') {
    checkLoginStatus();
    sendResponse({ status: 'checked' });
  }
  
  if (request.action === 'resetLoginAttempt') {
    loginAttempted = false;
    console.log('Tab Keeper Content: Login attempt reset');
    sendResponse({ status: 'reset' });
  }
  
  if (request.action === 'dismissPasswordPopup') {
    const dismissed = dismissPasswordPopup();
    sendResponse({ status: dismissed ? 'dismissed' : 'not_found' });
  }
  
  return true; // Keep channel open
});

// Start when page is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', startLoginMonitoring);
} else {
  startLoginMonitoring();
}

// Cleanup
window.addEventListener('beforeunload', () => {
  if (loginCheckTimeout) {
    clearTimeout(loginCheckTimeout);
  }
});
